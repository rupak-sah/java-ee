#!/bin/bash
#
# Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
#
# This script checks that the basic health of the VM is fine
#
